<!DOCTYPE HTML>
<html lang="en-US">
<head>
	
	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width , initial-scale=1"/>
	<meta name="keywords" content="bike, bicycle, bycylce in bangladesh "/>
	<meta name="description" content="the website need to seo friendly then we add meta keywoeds , meta description, meta viewport , meta charset "/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	
	<title>EARS</title>
	
	<!-- styleshetts -->
	
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/normalize.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="style.css" media="all" />
	<link rel="stylesheet" type="text/css" href="responsive.css" media="all" />
	<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Great+Vibes" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Great+Vibes|Gudea:400i|Ranga" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Anton|Oswald" rel="stylesheet">
	<link rel="shortcut icon" type="image/x-icon" href="favicon.jpg" />
	
	<!--[if lt ie 9]> <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script> <![endif]-->
</head>
<body>

	<header> 
		<nav class="main-menu"> 
			<div class="logo"> 
				<h4>Shihab</h4>
			</div>
			<div class="menu">
				<a href="#" class="bar"><i class="fa fa-bars"></i></a>
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Submit Applications</a></li>
					<li><a href="#">Manage Faculty</a></li>
					<li><a href="#">Manage Applications</a></li>
                                        <li><a href="login.php">Manage Accounts</a></li>
				</ul>
			</div>
		</nav>		
		
		<div class="text-area"> 
			<h3>Welcome to our EARS System !</h3>
			<h2>.......</h2>
		</div>
		<div class="button-area"> 
			<a href="#">See more</a>
		</div>
	
	
	</header>
	
	<section> 
	<div class="team-area">
			<div class="container"> 
				<div class="team-text"> 
					<h2>services</h2>
					<p> </p>
				</div>
				<div class="all-image">
				
					<div class="image-1 gender col-md-4">
						<i class="glyphicon glyphicon-trash"></i>
						<h2>About Faculty</h2>
						<p>prion iaculs purus consequant sem cure digni ssum.Donec porttitora entum suscipit aenean rhoncus posuere odio in tincident.</p>
						
					</div>
					
						<div class="image-2 gender col-md-4">
						<i class="fa fa-check-square "></i>
						<h2>About Authority</h2>
						<p>prion iaculs purus consequant sem cure digni ssum.Donec porttitora entum suscipit aenean rhoncus posuere odio in tincident.</p>
						
					</div>
					
					<div class="image-3 gender col-md-4">
						<i class="glyphicon glyphicon-lock"></i>
						<h2>About Institution</h2>
						<p>prion iaculs purus consequant sem cure digni ssum.Donec porttitora entum suscipit aenean rhoncus posuere odio in tincident.</p>
						
					</div>
					
				
			</div>
		</div>
	</section>
	
	<footer> 
		<div class="portfolio-area"> 
			<h2>Our EARS</h2>
			<p>prion iaculs purus consequant sem cure </p>
		</div>
	</footer>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="script.js"></script>
</body>
</html>