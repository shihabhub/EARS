jQuery(document).ready(function() {
	jQuery(".bar").click(function(){
		jQuery(".main-menu ul").slideToggle();
	});
	jQuery(window).resize(function() {
		if(jQuery(window).width()<768){
		jQuery(".main-menu ul").hide();
		}
		else{
			jQuery(".main-menu ul").show();
		}
	});
});