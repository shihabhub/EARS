<?php
    require_once('functions/function.php');
    get_part('header.php');
    get_part('sidebar.php');
    get_part('bread.php');
    
    if(isset($_POST['send'])){
		$name=htmlentities($_POST['name'],ENT_QUOTES);
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$username=$_POST['username'];
		$password=md5($_POST['pass']);
		$user_role=$_POST['role'];
		
		if(empty($username)||(empty($password))){
			echo"<script>window.alert('please fill up the required fields!!')</script>";
 			exit();
			}
		else{	
		$insert="INSERT INTO cit_user(user_name,user_email,user_phone,user_username,user_password,role_id)VALUES('$name','$email','$phone','$username','$password','$user_role')";
		$qry=mysqli_query($con,$insert);
		if($qry){
                        echo 'Inserted successfull!!';;
			}
			else{
				 echo"window.alert('Product insert Failed!!')";
				}
		}
            }
?>
<div class="row">
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title box_title_info">User Registration</h3>              
                <a href="all-user.php" class="top_button"><i class="fa fa-th"></i> All User</a>
            </div>

            <form class="form-horizontal" method="post" action="">
                <div class="box-body">      
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        
                        
                            <!--<div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                
                            </div>
                        
                        
                            <div class="alert alert-danger" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                               
                            </div>-->
                       
                    </div>
                    <div class="col-md-2"></div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Name <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" name="name" class="form-control" id="">
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Email <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" name="email" value="" class="form-control" id="" placeholder="">
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Phone <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" name="phone" class="form-control" id="" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Username <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" name="username" class="form-control" id="" placeholder="">
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Password <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="password" name="pass" class="form-control" id="" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Select User Role <span class="req_star">*</span></label>
                        <div class="col-sm-3">
                            <select name="role" class="form-control">
                                <option>Select Role</option>
                                <?php
				  	$select="select * from cit_role";
					$query=mysqli_query($con,$select);
					while($data=mysqli_fetch_array($query)){
				  ?>
                                <option value="<?=$data['role_id'];?>"><?=$data['role_name'];?></option>
                                        <?php };?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="box-footer text-center">
                    <button type="submit" value="send" name="send" class="btn btn-primary">USER REGISTRATION</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
    
        get_part('footer.php');
?>