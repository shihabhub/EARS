<?php
    require_once('functions/function.php');

    get_part('header.php');
    get_part('sidebar.php');
    get_part('bread.php');
    get_part('infobar.php');
    get_part('footer.php');
?>
