<aside class="main-sidebar">
    <section class="sidebar">
        <div class="user-panel">
            <div class="pull-left image">
                <img src="images/IMG_9547.JPG" class="img-circle" alt="user">
            </div>
            <div class="pull-left info">
                <p>Shihab</p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
                <span class="input-group-btn">
                    <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
        </form>
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
            <li><a href="all-user.php"><i class="fa fa-user"></i> <span>User</span></a></li>
            <li><a href=""><i class="fa fa-users"></i> <span>Applicants Information</span></a></li>
            <li><a href="#"><i class="fa fa-graduation-cap"></i> <span>Applications</span></a></li>
            <li><a href="#"><i class="fa fa-newspaper-o"></i> <span>Report</span></a></li>
            <li><a href="logout.php"><i class="fa fa-sign-out"></i> <span>Log Out</span></a></li>
        </ul>
    </section>
</aside>