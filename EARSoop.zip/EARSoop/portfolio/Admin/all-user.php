<?php
    require_once('functions/function.php');
    get_part('header.php');
    get_part('sidebar.php');
    get_part('bread.php');
?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title box_title_info">All User Information</h3>
                <a href="add-user.php" class="top_button"><i class="fa fa-plus-square"></i> Add User</a>
            </div>
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>User Role</th>
                            
                            <th>Manage</th>
                        </tr>
                    </thead>
                    <tbody>  
                    <?php
                                        $sel="select * from cit_user natural join cit_role order by user_id desc";
					$qry=mysqli_query($con,$sel);
					while($data=mysqli_fetch_array($qry)){
                    ?>                        
                        <tr>
                            <td><?=html_entity_decode($data['user_name']);?></td>
                            <td><?=$data['user_email'];?></td>  
                            <td><?=$data['user_username'];?></td> 
                            <td><?=$data['role_name'];?></td>
                            
                            <td>
                                <a href=""><i class="fa fa-plus-square man_view"></i></a>
                                <a href=""><i class="fa fa-edit man_edit"></i></a>
                                <a href=""><i class="fa fa-trash man_delete"></i></a>
                            </td>
                        </tr>
                                        <?php };?>
                    </tbody>                  
                </table>
            </div>
        </div>
    </div>
</div>
<?php
        get_part('footer.php');
?>
