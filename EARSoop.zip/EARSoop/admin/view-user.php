<div class="row">
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title box_title_info">Subject Information</h3>              
                <a href="<?= base_url('Role');?>" class="top_button"><i class="fa fa-th"></i> All Role</a>
            </div>
            
            <form class="form-horizontal">
                <div class="box-body">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8">
                        <table class="table table-bordered table-hover view_table_info">
                            <tr>
                                <td>Role Name</td>
                                <td>:</td>
                                <td><?= $data->role_name;?></td>
                            </tr>
                            <tr>
                                <td>Role Id</td>
                                <td>:</td>
                                <td><?= $data->id;?></td>
                            </tr>
                            <tr>
                                <td>Creator</td>
                                <td>:</td>
                                <td><?= $data->creator;?></td>
                            </tr>
                            <tr>
                                <td>Create Time</td>
                                <td>:</td>
                                <td>16-01-2017 10:12:25 AM</td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-sm-2"></div>
                </div>
                <div class="box-footer">
                    <button class="btn btn-primary btn-sm">PDF</button>
                    <button class="btn btn-success btn-sm">CSV</button>
                    <button class="btn btn-danger btn-sm">Excel</button>
                    <button class="btn btn-warning btn-sm">Print</button>
                </div>
                <!-- /.box-footer -->
            </form>
        </div>
    </div>
</div>