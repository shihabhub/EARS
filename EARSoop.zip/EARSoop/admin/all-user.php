<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title box_title_info">All User Information</h3>
                <a href="<?= base_url('User/add');?>" class="top_button"><i class="fa fa-plus-square"></i> Add User</a>
            </div>
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>User Role</th>
                            <th>Creator</th>
                            <th>Manage</th>
                        </tr>
                    </thead>
                    <tbody>  
                        <?php foreach($userInfo as $data){ ?>
                        <tr>
                            <td><?= $data->name; ?></td>
                            <td><?= $data->email; ?></td>  
                            <td><?= $data->username; ?></td> 
                            <td></td>
                            <td><?= $data->creator_id;?></td>
                            <td>
                                <a href="<?= base_url('User/view/').$data->id;?>"><i class="fa fa-plus-square man_view"></i></a>
                                <a href="<?= base_url('User/edit/').$data->id;?>"><i class="fa fa-edit man_edit"></i></a>
                                <a href="<?= base_url('User/delete/').$data->id;?>"><i class="fa fa-trash man_delete"></i></a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>                  
                </table>
            </div>
        </div>
    </div>
</div>
