$(document).ready(function () {
    submitForm = function (that, redirect, formReset) {
        formReset = typeof formReset !== 'undefined' ? formReset : true;
        $that = $(that);
        var $thatForm = $that.parents("form");
        $($thatForm).one("submit", function () {
            e.preventDefault();
            $btnVal = $that.val();
            $that.attr({"disabled": "disabled"});
            $that.val("Please Wait...");
            fd = new FormData(this);
            $.ajax({
                url: "submit",
                type: "POST",
                data: fd,
                processData: false,
                contentType: false,
                mimeType: "multipart/form-data",
                dataType: "json",
                success: function (r) {
                    $that.removedAttr("disabled");
                    $that.val($btnVal);
                    if (r.success) {
                        //alert(r.message);
                        $("div.alert-danger").hide();
                        $("div.alert-success").html(r.message).fadeIn();
                        if (formReset) {
                            $thatForm.trigger('reset');
                        }
                        if (redirect) {
                            setTimeout(function () {
                                location.href = redirect;
                            }, 5000);
                        } else if (redirect === false) {
                        } else {
                            setTimeout(function () {
                                location.href = redirect;
                            }, 5000);
                        }
                    } else {
                        $("div.alert-success").hide();
                        $("div.alert-danger").html(r.message).fadeIn();
                        setTimeout(function () {
                            $("div.alert-danger").slideUp()
                        }, 10000);
                    }
                },
                error: function (a, b, c) {
                    $that.removeAttr("disabled");
                    $that.val($btnVal);
                    alert("Ajax ERROR!!!\n");
                }
            });
            return false;
        });
    }//submit Data 
    submitFormLogin = function (that, redirect) {
        $that = $(that);
        var $thatForm = $that.parents("form");
        $($thatForm).one("submit", function (e) {
            e.preventDefault();
            $btnVal = $that.val();
            $that.attr({"disabled": "disabled"});
            $that.val("Please Wait...");
            fd = new FormData(this);
            //alert($thatForm.serialize());
//            alert(BASE_URL+"submit");
            $.ajax({
                url: BASE_URL + "/Process/login",
                type: "POST",
                data: fd,
                processData: false,
                contentType: false,
                mimeType: "multipart/form-data",
                dataType: "json",
                success: function (r) {
                    //alert(r);
                    $that.removeAttr("disabled");
                    $that.val($btnVal);
                    if (r.success) {
                        if (redirect) {
                            location.href = redirect;
                        }
                        //alert(r.message);
                        $thatForm.trigger('reset');
                    } else {
                        $("div.alert-danger").html(r.message).fadeIn();
                        //alert(r.message);
                    }
                },
                error: function (a, b, c) {
                    $that.removeAttr("disabled");
                    $that.val($btnVal);
                    alert("Ajax ERROR!!!\n" + a.responseText);
                }
            });
            return false;
        });
    }
});