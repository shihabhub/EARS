<div class="row">
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title box_title_info">User Registration</h3>              
                <a href="<?= base_url('User'); ?>" class="top_button"><i class="fa fa-th"></i> All User</a>
            </div>

            <form class="form-horizontal" method="post" action="<?= base_url('process'); ?>">
                <div class="box-body">      
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        <?php
                        $this->securityMod->set_action('save_user');
                        $success = $this->session->flashdata('success');
                        $error = $this->session->flashdata('error');
                        ?>
                        <?php if (!empty($success)) { ?>
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <?= $success ?>
                            </div>
                        <?php } ?>
                        <?php if (!empty($error)) { ?>
                            <div class="alert alert-danger" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <?= $error ?>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="col-md-2"></div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Name <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" name="name" class="form-control" id="">
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Email <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" name="email" value="" class="form-control" id="" placeholder="">
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Username <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" name="username" class="form-control" id="" placeholder="">
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Password <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="password" name="password" class="form-control" id="" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Confirm Password <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="password" name="conpass" class="form-control" id="" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Select User Role <span class="req_star">*</span></label>
                        <div class="col-sm-3">
                            <select name="role" class="form-control select2">
                                <option>Select Role</option>
                                <?php
                                foreach ($allRole as $Role) {
                                    echo '<option value="' . $Role->role_id . '">' . $Role->role_name . '</option>';
                                }
                                ?>                                                               
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Upload <span class="req_star">*</span></label>
                        <div class="col-sm-3">
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" name="pic" id="imgInp">
                                    </span>
                                </span>
                                <input type="text" class="form-control" readonly>
                            </div>
                            <img id='img-upload'/>
                        </div>
                    </div>
                </div>
                <div class="box-footer text-center">
                    <button type="submit" class="btn btn-primary">USER REGISTRATION</button>
                </div>
            </form>
        </div>
    </div>
</div>