<div class="row">
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title box_title_info">Edit Subject Information</h3>              
                <a href="<?= base_url('subject');?>" class="top_button"><i class="fa fa-th"></i> All Subject</a>
            </div>
            
            <form class="form-horizontal">
                <div class="box-body">
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Subject Code <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Subject Name <span class="req_star">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Author</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="" placeholder="(optional)" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Paper</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="" value="" placeholder="(optional)">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Version</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="" value="" placeholder="(optional)">
                        </div>
                    </div>
                </div>
                <div class="box-footer text-center">
                    <button type="submit" class="btn btn-primary">UPDATE</button>
                </div>
                <!-- /.box-footer -->
            </form>
        </div>
    </div>
</div>